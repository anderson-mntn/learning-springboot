package dio.configurationpropertieslesson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigurationPropertiesLessonApplicationTests {

	@Test
	void contextLoads() {
	}

}
