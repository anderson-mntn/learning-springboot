package dio.configurationpropertieslesson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigurationPropertiesLessonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigurationPropertiesLessonApplication.class, args);
	}

}
